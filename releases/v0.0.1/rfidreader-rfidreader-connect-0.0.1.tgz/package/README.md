# RFIDReaderConnect (Web)

TypeScript SDK to connect and command **Mark3 RFID readers** from browsers and Node — mirrors the [iOS](https://github.com/RFIDReader/RFIDReaderConnect-swift) and [Android](https://github.com/RFIDReader/RFIDReaderConnect-kt) SDKs 1:1 for the reader / module command surface.

## Install

```bash
npm install @rfidreader/rfidreader-connect
```

## Transports

| Transport | Browser API | Notes |
|---|---|---|
| `BLETransport` | Web Bluetooth | Chrome / Edge / Opera |
| `USBTransport` | WebUSB | Chrome / Edge (CDC-ACM, VID `0x303A` by default) |
| `WebSocketTransport` | `ws://<host>/ws` | any modern browser |
| `RESTTransport` | `http://<host>/rest` | any modern browser; auto-`GET /resolve` for `.local` hosts |
| `BridgeTransport` | `window.RFIDReader` | for web apps hosted inside the iOS/Android app |

## Usage

```ts
import {
  RFIDReader,
  RFIDReaderModel,
  BLETransport,
  defaultDelegate,
  RFIDReaderRegion,
} from "@rfidreader/rfidreader-connect";

const transport = new BLETransport(undefined, { hostname: "mark3-abcdef" });
const reader = new RFIDReader({
  model: RFIDReaderModel.MARK3_HH7,
  transport,
  delegate: {
    ...defaultDelegate,
    rfidReaderDidReadTag(tag) {
      console.log("tag", tag.epc);
    },
  },
});

await reader.connect();
await reader.setRegion(RFIDReaderRegion.FCC);
await reader.startAsyncInventory();
```

## Development

```bash
npm install
npm test           # vitest
npm run typecheck  # tsc --noEmit
npm run build      # -> dist/
```

## Layout

| Path | Purpose |
|---|---|
| `src/messages/Messenger.ts` | frame builders for every reader / module command |
| `src/messages/MessageParser.ts` | typed parsers for every response the reader emits |
| `src/messages/AsyncInventoryParser.ts` | streaming parser for async inventory (heartbeat / start / stop / tag) |
| `src/transport/*` | `BLE`, `USB`, `WebSocket`, `REST`, `Bridge` transports |
| `src/types.ts` | enums + value objects (`RFIDReaderRegion`, `RFIDTag`, …) |
| `src/utils/crc.ts` | CCITT CRC-16 (with the reader's "skip byte 0" quirk), sub-CRC, hex + int helpers |
| `src/RFIDReader.ts` | main facade; wires transport ↔ parsers ↔ delegate |

## License

Proprietary — see [LICENSE](LICENSE).
